from django.apps import AppConfig


class CaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CA'
